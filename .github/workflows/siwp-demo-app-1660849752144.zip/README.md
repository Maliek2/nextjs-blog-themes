# Sign in with Paxful demo application

This application demonstrates how to integrate an application with Sign in with Paxful product.

# Configuration

For executing this project you need to have `docker` and `docker-compose` installed in your machine, please follow the guide:
[https://docs.docker.com/get-docker/](https://docs.docker.com/get-docker/)

# Running the app

If you have downloaded the application through https://developers.paxful.com then the only thing you need to do is to 
run `docker-compose up --build` and then open `http://localhost:3000` in the browser.

If you have cloned a repository manually then:
* Create an application on https://developers.paxful.com
* After the application is created, update its `Redirect URIs` parameter to have `http://localhost:3000/auth/paxful/callback`
* Run `cp .env.example .env`, review and update `PAXFUL_API_ID` and `PAXFUL_API_SECRET` parameters
* Run `docker-compose up --build`
* Let it finish and then open  `http://localhost:3000` in your browser
* Enjoy

Please notice that we use nodemon for live-reload of the application, so any changes or added files will be reflected on runtime.