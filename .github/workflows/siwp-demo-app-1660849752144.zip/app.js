const express = require('express');
const session = require('express-session');
const path = require('path');
const logger = require('morgan');
const { default: usePaxful } = require("@paxful/sdk-js");

const route = require('./routes');

const app = express();

// Create a logger middleware with dev format
// https://www.npmjs.com/package/morgan#dev
app.use(logger('dev'));
// Create a session middleware to be used by the application
// https://www.npmjs.com/package/express-session
app.use(session({
    // https://www.npmjs.com/package/express-session#store
    // store:
    // https://www.npmjs.com/package/express-session#name
    name: process.env.APP_NAME,
    // https://www.npmjs.com/package/express-session#secret
    secret: process.env.APP_SECRET,
    // https://www.npmjs.com/package/express-session#resave
    resave: true,
    // https://www.npmjs.com/package/express-session#saveuninitialized
    saveUninitialized: true,
    cookie: {
        httpOnly: true,
        sameSite: 'lax',
        secure: false
    }
}));
// Add json body parser for expressjs
// https://expressjs.com/en/5x/api.html#express.json
app.use(express.json());
// Add url encoded body parser for expressjs
// https://expressjs.com/en/5x/api.html#express.urlencoded
app.use(express.urlencoded({extended: false}));

// Set the template engine to pug
// https://pugjs.org/api/getting-started.html
app.set('view engine', 'pug');
// Path to page templates
app.set('views', path.join(__dirname, 'views'));
// Initilize paxful token storage
app.use((req, res, next) => {
    // We would need a middleware to initialize it because the token service depends on the request to
    // get the correct token for the user
    const getCredentialStorage = (req) => ({
        getCredentials: () => req.session.tokens,
        saveCredentials: tokens => {
            req.session.tokens = tokens;
            req.session.save(() => {
                console.log("Tokens saved!");
            });
        }
    });
    req.paxfulApi = usePaxful({
        clientId: process.env.PAXFUL_API_ID,
        clientSecret: process.env.PAXFUL_API_SECRET,
        redirectUri: `http://${process.env.APP_DOMAIN}${process.env.CALLBACK_URL}`,
        scope: [
            'profile',
            'email'
        ]
    }, getCredentialStorage(req));
    next();
});
// Set routes for the application
app.use('/', route);
// Path for static files
app.use(express.static(path.join(__dirname, 'public')));

module.exports = app;
