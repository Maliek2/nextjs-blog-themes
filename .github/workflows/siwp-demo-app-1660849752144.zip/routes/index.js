const express = require('express');

const pageRouter = require('./page');
const paxfulRouter = require('./paxful');

const routerAggregator = express.Router();

routerAggregator.use(paxfulRouter);
routerAggregator.use(pageRouter);

module.exports = routerAggregator;
