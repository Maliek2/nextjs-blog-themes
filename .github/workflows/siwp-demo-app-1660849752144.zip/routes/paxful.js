const express = require('express');

const router = express.Router();

router.get('/auth/paxful', (req, res) => {
    req.paxfulApi.login(res);
});

router.get('/auth/paxful/callback', async (req, res, next) => {
    await req.paxfulApi.impersonatedCredentials(req.query.code)
    res.redirect("/");
});

module.exports = router;
