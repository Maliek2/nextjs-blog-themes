const express = require('express');

const router = express.Router();

router.get('/', async (req, res) => {
    // req.user will be set only if user has already passed oauth.
    const user = await req.paxfulApi.getProfile().catch(_ => null);
    res.render('index', {title: 'Paxful Sign in with Paxful Demo', user})
});

module.exports = router;
