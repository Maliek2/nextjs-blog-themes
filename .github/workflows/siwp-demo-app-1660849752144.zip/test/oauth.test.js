const request = require('supertest');
const dotenv = require('dotenv');

dotenv.config();

const app = require('../app');

describe('I would like to login with my Paxful account', () => {
    it('Redirect me to account service', async (done) => {
        request(app)
            .get('/auth/paxful')
            .expect(302)
            .expect('Location', /\/oauth2\/authorize(.*)/)
            .end(done);
    });
});