global.fetch = require('jest-fetch-mock');

fetch.enableFetchMocks();